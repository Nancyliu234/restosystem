<footer>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
            <!-- Copyright info -->
            <p class="copy center">Copyright &copy; 2023 | <a href="#">Online Restaurant Management System</a> </p>
      </div>
    </div>
  </div>
</footer> 